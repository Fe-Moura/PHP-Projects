<?php
	require "./bibliotecas/PHPMailer/Exception.php";
	require "./bibliotecas/PHPMailer/OAuth.php";
    require "./bibliotecas/PHPMailer/OAuthTokenProvider.php";
	require "./bibliotecas/PHPMailer/PHPMailer.php";
	require "./bibliotecas/PHPMailer/POP3.php";
	require "./bibliotecas/PHPMailer/SMTP.php";

    require "../Arquivos-AppSendMail/processa_envio.php"

?>