<?php
    require 'QRCode.class.php';

    $oQRC = new QRCode; 
    $oQRC->fullName('Felipe Moura Pereira') 
        ->nickName('Mr. Pereira') 
        ->gender('M') 
        ->workPhone('+55 (11)98234-7773')
        ->email('Felipe.Pereira@SchulerGroup.com') 
//        ->impp('phs_7@aol.com') 
        ->organization('Prensas Schuler Brasil (PSB)')
        ->address('Av. Fagundes de Oliveira, 1515 - Piraporinha, Diadema - SP, 09950-904')
        ->url('https://www.schulergroup.com/minor/br/index.html') 
        ->note('A Prensas Schuler instalou-se no Brasil em 1965, época de grande'
             . ' desenvolvimento da indústria, em particular a automotiva, '
             . 'assumindo imediatamente a posição ocupada até hoje: líder do mercado nacional'
             . ' de prensas de grande porte. A partir da sua fábrica em Diadema, São Paulo '
             . '– a terceira maior do Grupo Schuler fora da Alemanha '
             . '– as prensas Schuler são exportadas para o mundo inteiro.') 
        ->categories('developer/designer') 
        ->photo('schulerLogo.png') 
        ->lang('en-US')
        ->finish(); 
        //$oQRC->display(300); // Set size and display QR Code default 150px
    
    
    
    
    
?>


 <!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Contato</title>
	<head>
	<body>
		<?php
		$arquivo = 'msgcontatos.xls';
		$html = '';

		$html .= $oQRC->display(300); 
		
		header ("Expires: Mon, 07 Jul 2016 05:00:00 GMT");
		header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
		header ("Cache-Control: no-cache, must-revalidate");
		header ("Pragma: no-cache");
		header ("Content-type: application/x-msexcel");
		header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
		header ("Content-Description: PHP Generated Data" );

                echo $html;
		exit;?>
	</body>
</html>