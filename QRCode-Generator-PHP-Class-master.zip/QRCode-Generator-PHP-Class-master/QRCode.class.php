<?php
class QRCode
{
    const API_URL = 'https://chart.googleapis.com/chart?chs=';
    const DEFAULT_QR_SIZE = 150;

    private $sData;

    public function __construct()
    {
        $this->sData = 'BEGIN:VCARD' . "\n";
        $this->sData .= 'VERSION:4.0' . "\n";
    }

    public function name($sName)
    {
        $this->sData .= 'N:' . $sName . "\n";
        return $this;
    }
    
    public function fullName($sFullName)
    {
        $this->sData .= 'FN:' . $sFullName . "\n";
        return $this;
    }

    public function address($sAddress)
    {
        $this->sData .= 'ADR:' . $sAddress . "\n";

        return $this;
    }

    public function nickName($sNickname)
    {
        $this->sData .= 'NICKNAME:' . $sNickname . "\n";
        return $this;
    }


    public function email($sMail)
    {
        $this->sData .= 'EMAIL;TYPE=PREF,INTERNET:' . $sMail . "\n";
        return $this;
    }

    public function workPhone($sVal)
    {
        $this->sData .= 'TEL;TYPE=WORK:' . $sVal . "\n";
        return $this;
    }


    public function homePhone($sVal)
    {
        $this->sData .= 'TEL;TYPE=HOME:' . $sVal . "\n";
        return $this;
    }


    public function url($sUrl)
    {
        $sUrl = (substr($sUrl, 0, 4) != 'http') ? 'http://' . $sUrl : $sUrl;
        $this->sData .= 'URL:' . $sUrl . "\n";
        return $this;
    }

    public function sms($sPhone, $sText)
    {
        $this->sData .= 'SMSTO:' . $sPhone . ':' . $sText . "\n";
        return $this;
    }

    public function birthday($sBirthday)
    {
        $this->sData .= 'BDAY:' . $sBirthday . "\n";
        return $this;
    }

    public function anniversary($sBirthDate)
    {
        $this->sData .= 'ANNIVERSARY:' . $sBirthDate . "\n";
        return $this;
    }

    public function gender($sSex)
    {
        $this->sData .= 'GENDER:' . $sSex . "\n";
        return $this;
    }

    public function categories($sCategories)
    {
        $this->sData .= 'CATEGORIES:' . $sCategories . "\n";
        return $this;
    }

    public function impp($sVal)
    {
        $this->sData .= 'IMPP:' . $sVal . "\n";
        return $this;
    }

    public function photo($sImgUrl)
    {
        $bIsImgExt = strtolower(substr(strrchr($sImgUrl, '.'), 1)); // Get the file extension.

        if ($bIsImgExt == 'jpeg' || $bIsImgExt == 'jpg' || $bIsImgExt == 'png' || $bIsImgExt == 'gif') {
            $sExt = strtoupper($bIsImgExt);
        } else {
            throw new InvalidArgumentException('Invalid format Image!');
        }

        $this->sData .= 'PHOTO;VALUE=URL;TYPE=' . $sExt . ':' . $sImgUrl . "\n";

        return $this;
    }

    public function role($sRole)
    {
        $this->sData .= 'ROLE:' . $sRole . "\n";
        return $this;
    }

    public function organization($sOrg)
    {
        $this->sData .= 'ORG:' . $sOrg . "\n";
        return $this;
    }

    public function note($sText)
    {
        $this->sData .= 'NOTE:' . $sText . "\n";
        return $this;
    }

    public function bookmark($sTitle, $sUrl)
    {
        $this->sData .= 'MEBKM:TITLE:' . $sTitle . ';URL:' . $sUrl . "\n";
        return $this;
    }

    public function geo($sLat, $sLon, $iHeight)
    {
        $this->sData .= 'GEO:' . $sLat . ',' . $sLon . ',' . $iHeight . "\n";
        return $this;
    }
    
    public function lang($sLang)
    {
        $this->sData .= 'LANG:' . $sLang . "\n";
        return $this;
    }

    public function wifi($sType, $sSsid, $sPwd)
    {
        $this->sData .= 'WIFI:T:' . $sType . ';S' . $sSsid . ';' . $sPwd . "\n";
        return $this;
    }

    public function finish()
    {
        $this->sData .= 'END:VCARD';
        $this->sData = urlencode($this->sData);
        return $this;
    }

    public function get($iSize = self::DEFAULT_QR_SIZE, $sECLevel = 'L', $iMargin = 1)
    {
        return self::API_URL . $iSize . 'x' . $iSize . '&cht=qr&chld=' . $sECLevel . '|' . $iMargin . '&chl=' . $this->sData;
    }

    public function display($iSize = self::DEFAULT_QR_SIZE)
    {
        echo '<p class="center"><img src="' . $this->_cleanUrl($this->get($iSize)) . '" alt="QR Code" /></p>';
    }

    private function _cleanUrl($sUrl)
    {
        return str_replace('&', '&amp;', $sUrl);
    }
}
