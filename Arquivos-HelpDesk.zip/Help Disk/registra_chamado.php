<?php

    session_start();

    //montagem do texto
    $titulo = str_replace('#', '-' , $_POST['titulo']);
    $categoria = str_replace('#', '-' , $_POST['categoria']);
    $descricao = str_replace('#', '-' , $_POST['descricao']);

    //usando o implode para juntar os chamados
    $chamados = [$_SESSION['id'], "$titulo", "$categoria" , "$descricao", PHP_EOL];
    $implode_chamados = implode('#',$chamados);

    //abrindo o arquivo
    $arquivo = fopen('../Arquivos-HelpDesk/arquivo.hd' , 'a');
    //escrevendo o texto
    fwrite($arquivo, $implode_chamados);
    //fechando o arquivo
    fclose($arquivo);

    header("Location: abrir_chamado.php");

?>