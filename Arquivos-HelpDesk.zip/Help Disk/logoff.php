<?php
    //remover indices do array de sessão
    #unset() remove indices de qualquer array

    //destruir variavel de sessão
    #session_destroy()

    session_start();
    session_destroy();
    header("Location: index.php");


?>  